


using UnityEngine;
using System.Collections;


// Script for the management of all the robot animations.
public class RobotAIAnimation : MonoBehaviour 
{
	
	public float minimumRunSpeed = 1.0f; 	// Min robot velocity.
	
	// Use this for initialization.
	void Start() 
	{
		// Set all animations to loop.
		// WrapMode.Loop : When time reaches the end of the animation clip, 
		//                 time will continue at the beginning.
		//                 When playing backwards it will do the opposite: 
		//                 it will jump to the end of the clip and continue from there. 
		//                 The animation will never automatically stop playing.
		GetComponent<Animation>().wrapMode = WrapMode.Loop;
		// Except our action animations, Dont loop those.
		// Animation[] : Returns the AnimationState with the input name.
		//
		// WrapMode.Once : When time reaches the end of the animation clip, 
		//                 the clip will automatically stop playing and time will be reset to beginning of the clip.
		//  * : Note that when playing backwards and when the time reaches the beginning the clip will automatically stop playing, 
		//      but the time won't be reset to the end: it will be kept at the beginning.
		GetComponent<Animation>()[ "shoot" ].wrapMode = WrapMode.Once;
		// Put idle and run in a lower layer. 
		// They will only animate if our action animations are not playing.
		// AnimationState.layer : The layer of the animation. 
		//                        When calculating the final blend weights, 
		//                        animations in higher layers will get their weights distributed first. 
		//                        Lower layer animations only receive blend weights 
		//                        if the higher layers didn't use up all blend weights.
		GetComponent<Animation>()[ "idle" ].layer = -1;
		GetComponent<Animation>()[ "walk" ].layer = -1;
		GetComponent<Animation>()[ "run" ].layer = -1;
		// Animation.Stop() : Stops all playing animations that were started with this Animation.
		//                    Stopping an animation also rewinds it to the start.
		GetComponent<Animation>().Stop();
	}
	
	// Update is called once per frame.
	void Update() {}
	
	// Function to set the robot velocity.
	void SetSpeed( float speed )
	{
		// Check min robot speed.
		// Animation.CrossFade() : Fades the animation with input name in over a period of input seconds 
		//                         and fades other animations out.
		//                         If mode is PlayMode.StopSameLayer: 
		//                         animations in the same layer as animation will be faded out 
		//                         while animation is faded in. 
		//                         If mode is PlayMode.StopAll: 
		//                         all animations will be faded out while animation is faded in.
		//                         If the animation is not set to be looping:
		//                         it will be stopped and rewinded after playing.
		if( speed > minimumRunSpeed ) { GetComponent<Animation>().CrossFade( "run" ); }
		else { GetComponent<Animation>().CrossFade( "idle" ); }
	}
	
}


