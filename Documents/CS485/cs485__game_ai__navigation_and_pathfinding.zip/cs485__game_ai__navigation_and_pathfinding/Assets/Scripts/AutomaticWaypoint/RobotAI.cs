


using UnityEngine;
using System.Collections;

// RequireComponent : The RequireComponent attribute lets automatically add required component as a dependency.
//                    When you add a script which uses RequireComponent, 
//                    the required component will automatically be added to the game object. 
//                    This is useful to avoid setup errors. 
//                    For example a script might require that a rigid body is always added to the same game object. 
//                    Using RequireComponent this will be done automatically, thus you can never get the setup wrong.
[ RequireComponent( typeof( CharacterController ) ) ]


// Script to manage the combat behaviour of the robot enemy.
public class RobotAI : MonoBehaviour 
{
	
	public float speed = 3.0f; 						// Robot max speed.
	public float rotationSpeed = 5.0f; 				// Robot max rotation speed.
	public float shootRange = 15.0f; 				// Min range to enable firing.
	public float attackRange = 30.0f; 				// Min range to activate the targeting.
	public float shootAngle = 4.0f; 				// Min angle to enable firing.
	public float dontComeCloserRange = 5.0f; 		// Min distance from the target.
	public float delayShootTime = 0.35f; 			// Firing frequency.
	public float pickNextWaypointDistance = 2.0f; 	// Distance to check for the next waypoint.
	public Transform target; 						// Reference to the target game object.
	
	// Use this for initialization.
	void Start() 
	{
		// Auto setup player as target through tags.
		// GameObject.FindWithTag() : Returns one active GameObject tagged tag. 
		//                            Returns null if no GameObject was found.
		//                            Tags must be declared in the tag manager before using them.
		if( ( target == null ) && GameObject.FindWithTag( "Player" ) )
		{ target = GameObject.FindWithTag("Player").transform; }
		StartCoroutine( Patrol() );
	}
	
	// Update is called once per frame.
	void Update() {}
	
	// Coroutine to implement the patroling.
	IEnumerator Patrol()
	{
		AutomaticWaypoint curWaypoint = AutomaticWaypoint.FindClosest( transform.position );
		while( true )
		{
			Vector3 waypointPosition = curWaypoint.transform.position;
			// Are we close to a waypoint? -> Pick the next one!
			if( Vector3.Distance( waypointPosition, transform.position ) < pickNextWaypointDistance )
			{ curWaypoint = PickNextWaypoint( curWaypoint ); }
			// Attack the player and wait until: player is killed, or player is out of sight.
			if( CanSeeTarget() ) { yield return StartCoroutine( AttackPlayer() ); }
			// Move towards our target.
			MoveTowards( waypointPosition );
			yield return 0;
		}
	}
	
	// Check target available using distance and line of sight.
	bool CanSeeTarget()
	{
		// Vector3.Distance() : Returns the distance between A and B.
		//                      Vector3.Distance(A,B) is the same as (A-B).magnitude.
		if( Vector3.Distance( transform.position, target.position ) > attackRange ) 
		{ return false; }
		// RaycastHit : Structure used to get information back from a raycast.
		//              Variables :
		//               - point : 					The impact point in world space where the ray hit the collider.
		//               - normal : 				The normal of the surface the ray hit.
		//               - barycentricCoordinate : 	The barycentric coordinate of the triangle we hit.
		//               - distance : 				The distance from the ray's origin to the impact point.
		//               - triangleIndex : 			The index of the triangle that was hit.
		//               - textureCoord : 			The uv texture coordinate at the impact point.
		//               - textureCoord2 : 			The secondary uv texture coordinate at the impact point.
		//               - lightmapCoord : 			The uv lightmap coordinate at the impact point.
		//               - collider : 				The Collider that was hit.
		//               - rigidbody : 				The Rigidbody of the collider that was hit. 
		//                             				If the collider is not attached to a rigidbody then it is null.
		//               - transform : 				The Transform of the rigidbody or collider that was hit.
		RaycastHit hit;
		// Physics.Linecast() : Returns TRUE if there is any collider intersecting 
		//                      the line between input start pos and input end pos.
		if( Physics.Linecast( transform.position, target.position, out hit ) ) 
		{ return hit.transform == target; }
		return false;
	}
	
	// Coroutine to start the shoot animation clip and call the firing management.
	IEnumerator Shoot()
	{
		// Start shoot animation.
		// Animation.CrossFade() : Fades the input animation clip in over a period of input seconds 
		//                         and fades other animation clips out.
		//                         If mode is PlayMode.StopSameLayer: 
		//                         animations in the same layer as animation will be faded out while animation is faded in. 
		//                         If mode is PlayMode.StopAll: 
		//                         all animations will be faded out while animation is faded in.
		//                         If the animation is not set to be looping: 
		//                         it will be stopped and rewinded after playing.
		GetComponent<Animation>().CrossFade( "shoot", 0.3f );
		// Wait until half the animation has played.
		// WaitForSeconds() : Suspends the coroutine execution for the input amount of seconds.
		//                    WaitForSeconds() can only be used with a yield statement in coroutines.
		yield return new WaitForSeconds( delayShootTime );
		// Fire gun.
		// GameObject.BroadcastMessage() : Calls the input method on every MonoBehaviour in this game object 
		//									or any of its children.
		//                                 The receiving method can choose to ignore parameter 
		//									by having zero parameters. 
		//                                 If options is set to SendMessageOptions.RequireReceiver 
		//                                 an error is printed when the message is not picked up by any component.
		BroadcastMessage( "Fire" );
		// Wait for the rest of the animation to finish.
		yield return new WaitForSeconds( GetComponent<Animation>()[ "shoot" ].length - delayShootTime );
	}
	
	// Coroutine implementing the robot attack strategy.
	IEnumerator AttackPlayer()
	{
		// Track the last visible pos of the target.
		Vector3 lastVisiblePlayerPosition = target.position;
		// Infinite loop.
		while( true )
		{
			// Check target available.
			if( CanSeeTarget() )
			{
				// Target is dead -> stop hunting.
				if( target == null ) { 
										//return true;
										yield return true;
								}
				// Target is too far away -> give up.
				// Vector3.Distance() : Returns the distance between A and B.
				//                      Vector3.Distance(A,B) is the same as (A-B).magnitude.
				float distance = Vector3.Distance( transform.position, target.position );
				// Check target in range.
				if( distance > ( shootRange * 3 ) ) { 
										//return true; 
										yield return true;
								}
				// Update the last visible pos of the target.
				lastVisiblePlayerPosition = target.position;
				// Robot-target min distance check.
				if( distance > dontComeCloserRange ) { MoveTowards( lastVisiblePlayerPosition ); }
				else { RotateTowards( lastVisiblePlayerPosition ); }
				// Transform.TransformDirection() : Transforms direction from local space to world space.
				//                                  This operation is not affected by scale or position of the transform. 
				//                                  The returned vector has the same length as direction.
				Vector3 forward = transform.TransformDirection( Vector3.forward );
				Vector3 targetDirection = lastVisiblePlayerPosition - transform.position;
				targetDirection.y = 0.0f;
				// Vector3.Angle() : Returns the angle in degrees between input vectors A and B.
				float angle = Vector3.Angle( targetDirection, forward );
				// Start shooting if close and play is in sight.
				if( ( distance < shootRange ) && ( angle < shootAngle ) )
				{ yield return StartCoroutine( Shoot() ); }
			}
			else
			{
				yield return StartCoroutine( SearchPlayer( lastVisiblePlayerPosition ) );
				// Player not visible anymore -> stop attacking.
				if( !CanSeeTarget() ) { 
										//return true; 
										yield return true;
								}
			}
			yield return true;
		}
	}
	
	// Coroutine implementing a 3 seconds search to find the target again.
	IEnumerator SearchPlayer( Vector3 pos )
	{
		// Run towards the player but after 3 seconds timeout and go back to Patroling.
		float timeout = 3.0f;
		while( timeout > 0.0f )
		{
			MoveTowards( pos );
			// Check target available.
			if( CanSeeTarget () ) { 
								//return true; 
								yield return true;
						}
			timeout -= Time.deltaTime;
			yield return true;
		}
	}
	
	// Rotate the robot towards the target.
	void RotateTowards( Vector3 pos ) 
	{
		// Set the robot velocity to 0.
		// GameObject.SendMessage() : Calls the input method on every MonoBehaviour in this game object.
		//                            The receiving method can choose to ignore the argument by having zero parameters. 
		//                            If options is set to SendMessageOptions.RequireReceiver an error is printed 
		//                            when the message is not picked up by any component.
		SendMessage( "SetSpeed", 0.0f );
		Vector3 direction = pos - transform.position;
		direction.y = 0.0f;
		// Check direction vector magnitude.
		if( direction.magnitude < 0.1f ) { return; }
		// Rotate towards the target.
		// Quaternion.Slerp() : Spherically interpolates between 2 input quaternions using input time.
		transform.rotation = Quaternion.Slerp( transform.rotation, Quaternion.LookRotation( direction ), ( rotationSpeed * Time.deltaTime ) );
		transform.eulerAngles = new Vector3( 0.0f, transform.eulerAngles.y, 0.0f );
	}
	
	// Move the robot towards input pos.
	void MoveTowards( Vector3 pos )
	{
		Vector3 direction = pos - transform.position;
		direction.y = 0.0f;
		// Check direction vector magnitude.
		if( direction.magnitude < 0.5f ) 
		{ 
			// Set the robot velocity to 0.
			SendMessage( "SetSpeed", 0.0f );
			return;
		}
		// Rotate towards the target.
		// Quaternion.Slerp() : Spherically interpolates between 2 quaternions using input time.
		transform.rotation = Quaternion.Slerp( transform.rotation, 
												Quaternion.LookRotation( direction ), 
		                                      ( rotationSpeed * Time.deltaTime ) );
		transform.eulerAngles = new Vector3( 0.0f, transform.eulerAngles.y, 0.0f );
		// Modify speed so we slow down when we are not facing the target.
		Vector3 forward = transform.TransformDirection( Vector3.forward );
		// Vector3.Dot() : Dot Product of 2 vectors.
		//                 For normalized vectors Dot() returns: 
		//                  1 if they point in exactly the same direction; 
		//                 -1 if they point in completely opposite directions;
		//                  0 if vectors are perpendicular;
		//                 and a number in between [0,1] for other cases.
		//                 For vectors of arbitrary length the Dot() return values are similar: 
		//                 they get larger when the angle between vectors decreases.
		float speedModifier = Vector3.Dot( forward, direction.normalized );
		// Mathf.Clamp01() : Clamps value between 0 and 1 and returns value.
		speedModifier = Mathf.Clamp01( speedModifier );
		// Move the character.
		direction = forward * speed * speedModifier;
		// GameObject.GetComponent<T>() : Returns the component of type T if the game object has one attached, null if it doesn't. 
		//                                You can access both builtin components or scripts with this function.
		//                                GetComponent() is the primary way of accessing other components. 
		//                                From JAVASCRIPT the type of a script is always the name of the script as seen in the project view.
		// CharacterController.SimpleMove() : Moves the character with speed.
		//                                    Velocity along the y-axis is ignored. 
		//                                    Speed is in meters/s. Gravity is automatically applied. 
		//                                    Returns if the character is grounded. It is recommended that you make only one call to Move or SimpleMove per frame.
		GetComponent<CharacterController>().SimpleMove( direction );
		SendMessage( "SetSpeed", ( speed * speedModifier ), SendMessageOptions.DontRequireReceiver );
	}
	
	//
	AutomaticWaypoint PickNextWaypoint( AutomaticWaypoint currentWaypoint )
	{
		// We want to find the waypoint where the character has to turn the least.
		// The direction in which we are walking.
		Vector3 forward = transform.TransformDirection( Vector3.forward );
		// The closer two vectors, the larger the dot product will be.
		AutomaticWaypoint best = currentWaypoint;
		float bestDot = -10.0f;
		foreach( AutomaticWaypoint cur in currentWaypoint.connected )
		{
			// Vector3.Normalize() : Makes this vector have a magnitude of 1.
			//                       When normalized, a vector keeps the same direction but its length is 1.0.
			//  * : Note that this function will change the current vector. 
			//      If you want to keep the current vector unchanged, use Vector3.normalized variable.
			//  ** : If this vector is too small to be normalized it will be set to zero.
			//
			// Vector3.normalized : Returns this vector with a magnitude of 1 (Read Only).
			//                      When normalized, a vector keeps the same direction but its length is 1.0.
			//  * : Note that the current vector is unchanged and a new normalized vector is returned. 
			//      If you want to normalize the current vector, use Vector3.Normalize() function.
			//  ** : If the vector is too small to be normalized a zero vector will be returned.
			Vector3 direction = Vector3.Normalize( 
			                       cur.transform.position - transform.position );
			// Vector3.Dot() : Dot Product of 2 input vectors. 
			//                 For normalized vectors Dot() returns:
			//                   1 if they point in exactly the same direction; 
			//                   0 if vectors are perpendicular;
			//                  -1 if they point in completely opposite directions; 
			//                 and a number in between [0,1] for other cases.
			//                 For vectors of arbitrary length the Dot() return values are similar: 
			//                 they get larger when the angle between vectors decreases.
			float dot = Vector3.Dot( direction, forward );
			if( ( dot > bestDot ) && ( cur != currentWaypoint ) )
			{
				bestDot = dot;
				best = cur;
			}
		}
		return best;
	}
	
}


