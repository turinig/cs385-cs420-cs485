﻿


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestCoroutines : MonoBehaviour {

	public int i = 0;
	public float intervalTime = 2.0F; // Secs.

	private float elapsedTime = 0.0F;

	// Use this for initialization
	void Start () { StartCoroutine( Example()); }
	
	// Update is called once per frame
	void Update () {
		elapsedTime = elapsedTime + Time.deltaTime;
		if (elapsedTime >= intervalTime) {
			elapsedTime = 0.0F;
			i++;
			//flag = !flag;
		}
	}

	IEnumerator Example()
	{
				while (true) {
						yield return new WaitForSeconds (intervalTime);
						i++;
				}
	}

}
