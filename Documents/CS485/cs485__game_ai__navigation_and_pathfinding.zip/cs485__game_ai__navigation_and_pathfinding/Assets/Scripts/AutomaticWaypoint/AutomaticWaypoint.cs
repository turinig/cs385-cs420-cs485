


using UnityEngine;
using System.Collections;
using System.Collections.Generic;


// Waypoint class including global state and useful tools.
public class AutomaticWaypoint : MonoBehaviour 
{
	
	static public AutomaticWaypoint[] waypoints; 				// List of all waypoints.
	public AutomaticWaypoint[] connected; 						// List of waypoints connected to this.
	static public float kLineOfSightCapsuleRadius = 0.1f; 		// Radius for the waypont connection visibility check.
	
	// Return the closest waypoint to the input position.
	static public AutomaticWaypoint FindClosest( Vector3 pos )
	{
		// The closer two vectors, the larger the dot product will be.
		AutomaticWaypoint closest = waypoints[0];
		float closestDistance = 100000.0f;
		if( waypoints.Length == 0 ) { return null; }
		foreach( AutomaticWaypoint cur in waypoints )
		{
			if( cur != null )
			{
				// Vector3.Distance() : Returns the distance between A and B.
				//                      It is the same as (A-B).magnitude.
				float distance = Vector3.Distance( cur.transform.position, pos );
				if( distance < closestDistance )
				{
					closestDistance = distance;
					closest = cur;
				}
			}
		}
		return closest;
	}
	
	// [ ContextMenu() ] : Add a custom function to the script component context menu.
	[ ContextMenu( "Update Waypoints" ) ]
	void UpdateWaypoints() { RebuildWaypointList(); }
	
	// Search for all waypoints and recalculate connections.
	void Awake() { RebuildWaypointList(); }
	
	// Draw the waypoint pickable gizmo.
	// Gizmos.DrawIcon() : Draws an icon at a position in the scene view.
	//                     The image filename for the icon is specified with the name parameter 
	//                     while the center parameter denotes the location of the icon in world space 
	//                     and the allowScaling parameter determines if the icon is allowed to be scaled. 
	//                     The image file should be placed in the Assets/Gizmos folder.
	//                     DrawIcon() can be used to allow important objects in your game to be selected quickly.
	void OnDrawGizmos() { Gizmos.DrawIcon( transform.position, "Icon Waypoint.tif" ); } 		// The "W" gizmo.
	
	// Draw the waypoint lines only when you select one of the waypoints.
	void OnDrawGizmosSelected() 
	{
		if( waypoints != null )
		{
			// Length : The length property of the array that returns the number of elements in array.
			if( waypoints.Length == 0 ) { RebuildWaypointList(); }
			foreach( AutomaticWaypoint awp in connected ) 
			{
				if( awp != null )
				{
					// Physics.Linecast() : Returns TRUE if there is any collider intersecting the line between start and end.
					if( Physics.Linecast( transform.position, awp.transform.position ) ) 
					{
						// Gizmos : Gizmos are used to give visual debugging or setup aids in the scene view.
						//          All gizmo drawing has to be done in either OnDrawGizmos() or 
						//          OnDrawGizmosSelected() functions of the script.
						//           - OnDrawGizmos() is called every frame. 
						//             All gizmos rendered within OnDrawGizmos() are pickable.
						//           - OnDrawGizmosSelected() is called only if the object the script is attached to is selected.
						Gizmos.color = Color.red;
						// Gizmos.DrawLine() : Draws a line starting at A towards B.
						Gizmos.DrawLine( transform.position, awp.transform.position );
					}
					else
					{
						Gizmos.color = Color.green;
						Gizmos.DrawLine( transform.position, awp.transform.position );
					}
				}
			}
		}
	}
	
	// Search for all waypoints and recalculate connections.
	void RebuildWaypointList() 
	{
		// Object.FindObjectsOfType() : Returns a list of all active loaded objects of input type.
		//                              It will return no assets (meshes, textures, prefabs, ...) or inactive objects.
		// * : Please note that this function is very slow. 
		//     It is not recommended to use this function every frame. 
		//     In most cases you can use the singleton pattern instead.
		// Singleton Pattern : It is a design pattern that restricts the instantiation of a class to only 1 object (instance).
		//                     This is useful when exactly 1 object (instance) is needed to coordinate actions across the system.
		//
		//                     using System;
		//                     public class Singleton {
		//                        private static Singleton instance;
		//                        private Singleton() {}
		//                        public static Singleton Instance {
		//                           if (instance == null) { instance = new Singleton(); }
		//                           return instance;
		//                        }
		//                     }
		//
		waypoints = FindObjectsOfType( typeof( AutomaticWaypoint ) ) as AutomaticWaypoint[];
		foreach( AutomaticWaypoint awp in waypoints ) { 
			awp.RecalculateConnectedWaypoints(); }
	}
	
	// Recalculate waypoint connections.
	void RecalculateConnectedWaypoints()
	{
		// List<T> : Represents a strongly typed list of objects that can be accessed by index. 
		//           Provides methods to search, sort, and manipulate lists.
		List<AutomaticWaypoint> connectionList = new List<AutomaticWaypoint>();
		foreach( AutomaticWaypoint other in waypoints ) {
			// We don't want to connect to ourselves.
       		if( other == this ) { continue; }
			// Make sure we have a line of sight.
			// Physics.CheckCapsule() : Returns true if there are any colliders touching the capsule defined by 
			//                          the axis going from input start position to input end position 
			//                          and having radius in world coordinates.
			// List<T>.Add() : Adds an object to the end of the list.
			if( !( Physics.CheckCapsule( 	transform.position, 
											other.transform.position, 
											kLineOfSightCapsuleRadius ) ) ) 
			{ connectionList.Add( other ); } }
		// Update the connected waypoints.
		connected = new AutomaticWaypoint[ connectionList.Count ];
		// List<T>.CopyTo() : Copies the entire list to a compatible 1-dimensional array, 
		//                    starting at the beginning of the target array.
		connectionList.CopyTo( connected );
	}	

}


