﻿


using UnityEngine;
using System.Collections;

[ RequireComponent( typeof( UnityEngine.AI.NavMeshAgent ) ) ]
public class CarEngine : MonoBehaviour {

	public Transform destination;
	private UnityEngine.AI.NavMeshAgent agent;
	
	void Start() {
		agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
		agent.SetDestination( destination.position );
	}

	void StopCar() {
		//agent.Stop(true); // Obsolete.
		agent.Stop();
	}

	void ResumeCar() { agent.Resume(); }

	void OnTriggerEnter( Collider c ) {
		if( c.tag == "Car" ) { StopCar(); }
	}

	void OnTriggerExit( Collider c ) {
		if( c.tag == "Car" ) { ResumeCar(); }
	}

}


