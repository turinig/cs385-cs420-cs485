﻿


using UnityEngine;
using System.Collections;

public class TrafficLight : MonoBehaviour {

	private Material mat;
	private bool stop = true;
	private ArrayList stopped = new ArrayList();

	void UpdateColor() {
		if(stop) { mat.color = Color.red; }
		else  { mat.color = Color.green; }
	}

	void ResumeStopped() {
		for( int i = 0; i < stopped.Count; i++ ) {
			Collider c = (Collider)stopped[i];
			c.SendMessage( "ResumeCar" );
		}
		stopped.Clear();
	}

	void Start() {
		mat = GetComponentInChildren<MeshRenderer>().material;
		UpdateColor();
	}
	
	void Update() {
		if( Input.GetMouseButtonDown(0) ) {
			stop = !stop;
			UpdateColor();
			if(!stop) { ResumeStopped(); }
		}
	}

	void OnTriggerEnter( Collider c ) {
		if( stop && ( c.tag == "Car" ) ) {
			c.SendMessage( "StopCar" );
			stopped.Add( c );
		}
	}
}


