


using UnityEngine;
using System.Collections;

public class PriorityQueue {

	// Node array to store the priority queue.
	private ArrayList nodes = new ArrayList();

	// Number of nodes in the priority queue.
	public int Length {
		get{ return nodes.Count; }
	}

	// Check whether the node is already in the queue or not.
	public bool Contains( object node ) {
		return nodes.Contains( node );
	}

	// Get the first node in the queue.
	public Node First() {
		if( nodes.Count > 0 ) { return (Node) nodes[0]; }
		return null;
	}

	// Add the node to the priority queue and sort with the estimated total cost.
	public void Push( Node node ) {
		nodes.Add( node );
		nodes.Sort();
	}

	// Add the node from the priority queue and sort the remaining with the estimated total cost.
	public void Remove( Node node ) {
		nodes.Remove( node );
		nodes.Sort();
	}

}


