


using UnityEngine;
using System.Collections;

// ...
public class AStarTest : MonoBehaviour {
	
	public float intervalTime = 1.0f; // Interval time between path finding.
	public Node startNode { get; set; }
	public Node goalNode { get; set; }
	public ArrayList pathArray;

	private Transform startPos, endPos;
	private GameObject objStartCube, objEndCube;
	private float elapsedTime = 0.0f;
	
	void Start() {
		objStartCube = GameObject.FindGameObjectWithTag( "Start" );
		objEndCube = GameObject.FindGameObjectWithTag( "End" );
		// A* calculated path.
		pathArray = new ArrayList();
		FindPath();
	}

	void Update()  {
		elapsedTime += Time.deltaTime;
		if( elapsedTime >= intervalTime ) {
			elapsedTime = 0.0f;
			FindPath(); }
	}

	void FindPath() {
		startPos = objStartCube.transform;
		endPos = objEndCube.transform;
		// Assign the start node and goal node.
		startNode = new Node( 
						AStarGridManager.instance.GetGridCellCenter( 
								AStarGridManager.instance.GetGridIndex( 
										startPos.position ) ) );
		goalNode = new Node( 
						AStarGridManager.instance.GetGridCellCenter( 
								AStarGridManager.instance.GetGridIndex( 
										endPos.position ) ) );
		pathArray = AStar.FindPath( startNode, goalNode );
	}

	void OnDrawGizmos() {
		if( pathArray == null ) { return; }
		if( pathArray.Count > 0 ) {
			int index = 1;
			foreach( Node node in pathArray ) {
				if( index < pathArray.Count ) {
					Node nextNode = (Node) pathArray[ index ];
					Debug.DrawLine( node.position, nextNode.position, Color.cyan );
					index++; } } }
	}

}


