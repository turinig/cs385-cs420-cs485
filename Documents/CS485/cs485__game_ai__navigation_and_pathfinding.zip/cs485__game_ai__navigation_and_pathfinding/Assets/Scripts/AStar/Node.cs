


using UnityEngine;
using System.Collections;
using System;

public class Node : IComparable {
	
	public float nodeTotalCost; // Total cost so far for the node.
	public float estimatedCost; // Estimated cost from this node to the goal node.
	public bool bObstacle; // Does the node is an obstacle or not.
	public Node parent; // Parent of the node in the linked list.
	public Vector3 position; // Position of the node.
	
	// Default constructor.
	public Node() {
		estimatedCost = 0.0f;
		nodeTotalCost = 1.0f;
		bObstacle = false;
		parent = null;
	}

	// Constructor with adding position to the node creation.
	public Node( Vector3 pos ) {
		estimatedCost = 0.0f;
		nodeTotalCost = 1.0f;
		bObstacle = false;
		parent = null;
		position = pos;
	}

	// Make the node to be noted as an obstacle.
	public void MarkAsObstacle() { bObstacle = true; }

	// The CompareTo method affects the Sort method.
	// In this case the comparison uses the estimated total cost between two nodes.
	public int CompareTo( object obj ) {
		Node node = (Node) obj;
		if( this.estimatedCost < node.estimatedCost ) { return -1; }
		if( this.estimatedCost > node.estimatedCost ) { return 1; }
		return 0;
	}

}


