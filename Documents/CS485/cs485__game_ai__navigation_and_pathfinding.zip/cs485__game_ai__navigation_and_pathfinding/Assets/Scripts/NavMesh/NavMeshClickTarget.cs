﻿


using UnityEngine;
using System.Collections;

// ...
[RequireComponent (typeof (UnityEngine.AI.NavMeshAgent))]
public class NavMeshClickTarget : MonoBehaviour {

	private Camera cam;
	private UnityEngine.AI.NavMeshAgent agent;

	// ...
	void Start() {
		cam = GameObject.Find( "Main Camera" ).GetComponent<Camera>();
		agent = GetComponent<UnityEngine.AI.NavMeshAgent>();
	}
	
	// ...
	void Update() {
		// ...
		if( Input.GetButtonDown( "Fire1" ) ) {
			Ray r = cam.ScreenPointToRay( Input.mousePosition );
			RaycastHit hit;
			if( Physics.Raycast( r, out hit ) ) {
				if( hit.collider.gameObject.tag.Equals( "Clickable" ) ) {
					agent.SetDestination( hit.point ); } } }
		// ...
		if( Input.GetKeyDown( KeyCode.Space ) ) { 
			UnityEngine.AI.NavMesh.SetAreaCost( 3, 1.0f );
		}
	}

	void OnGUI() {
		GUI.contentColor = Color.black;
		GUI.Label( new Rect( 20, 20, 200, 20 ), "Left click to move the sphere." );
		GUI.Label( new Rect( 20, 40, 200, 20 ), "Press space to change the Water navigation layer cost." );
	}

}


