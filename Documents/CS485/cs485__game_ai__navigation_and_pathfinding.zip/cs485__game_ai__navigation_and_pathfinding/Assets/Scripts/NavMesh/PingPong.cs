﻿


using UnityEngine;
using System.Collections;

public class PingPong : MonoBehaviour {

	public float maxZ = 5.0f;
	public float minZ = -5.0f;
	public float velZ = 10.0f;

	// ...
	void Start() {}
	
	// ...
	void Update() {
		if( ( transform.position.z > maxZ ) || ( transform.position.z < minZ ) ) { velZ = -velZ; }
		transform.position += new Vector3( 0.0f, 0.0f, Time.deltaTime * velZ );
	}
}


