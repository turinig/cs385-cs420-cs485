


using UnityEngine;
using System.Collections;

// ...
public class ObstacleAvoidance : MonoBehaviour {
    
	public float speed = 20.0f;
	public float mass = 5.0f;
	public float force = 50.0f;
	public float minimumDistToAvoid = 20.0f;
	public int obstacleLayer = 8;

	// Actual speed of the unit.
	private float curSpeed;
	private Vector3 targetPoint;

	void Start() {
		mass = 5.0f;
		targetPoint = Vector3.zero;
	}

	void OnGUI() {
		GUILayout.Label( "Click anywhere to move the unit." );
	}

	void Update() {
		// Unit move by mouse click.
		RaycastHit hit;
		Ray ray = Camera.main.ScreenPointToRay( Input.mousePosition );
		if( Input.GetMouseButtonDown(0) && Physics.Raycast( ray, out hit, 100.0f ) ) {
			targetPoint = hit.point; }
		// Directional vector to the target position.
		Vector3 dir = targetPoint - transform.position;
		dir.Normalize();
		// Apply obstacle avoidance.
        AvoidObstacles( ref dir );
		// Don't move the unit when the target point is reached.
		if( Vector3.Distance( targetPoint, transform.position ) < 3.0f ) { return; }
		// Assign the speed with delta time.
		curSpeed = speed * Time.deltaTime;
		// Rotate the unit to its target directional vector.
        Quaternion rot = Quaternion.LookRotation( dir );
		transform.rotation = Quaternion.Slerp( transform.rotation, rot, 5.0f *  Time.deltaTime );
		// Move the unit towards.
		transform.position += transform.forward * curSpeed;
	}

	// Calculate the new directional vector to avoid the obstacle.
	public void AvoidObstacles( ref Vector3 dir ) {
		RaycastHit hit;
		// Only detect obstacle layer.
		int layerMask = 1 << obstacleLayer;
		// Check that the unit hit with the obstacles within a minimum distance to avoid.
        if( Physics.Raycast( transform.position, transform.forward, out hit, minimumDistToAvoid, layerMask ) ) {
			// Get the normal of the hit point to calculate the new direction.
			Vector3 hitNormal = hit.normal;
			hitNormal.y = 0.0f; // Don't want to move in Y-Space.
			// Get the new directional vector by adding force to the unity current forward vector.
			dir = transform.forward + hitNormal * force; }
	}

}


